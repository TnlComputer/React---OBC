const ROLES = {
  USER: "user",
  ADMIN: "admin",
};

export default ROLES;
