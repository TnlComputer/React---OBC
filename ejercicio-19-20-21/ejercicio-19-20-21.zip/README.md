# Ejercicios sesiones 19, 20 y 21

Hacer una petición HTTP con Axios a la API descrita en la web "https://api.chucknorris.io/" y crear un Componente React capaz de generar chistes aleatorios de Chuck Norris y mostrarlos.

Debe haber un botón que permita al usuario generar nuevos chistes.

También debe mostrarse un par de botones con Material UI que permitan votar (positivamente o negativamente un chiste).

Se debe mostrar el número de chistes te "han gustado" y cuántos "te han disgustado".
