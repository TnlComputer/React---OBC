import CardContainer from "./components/Card";

function App() {
  return (
    <div className="App">
      <CardContainer />
    </div>
  );
}

export default App;
