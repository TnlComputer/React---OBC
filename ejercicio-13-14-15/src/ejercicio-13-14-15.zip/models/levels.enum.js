const LEVELS = {
  NORMAL: "normal",
  URGENT: "urgent",
  BLOCKING: "blocking",
};

export default LEVELS;
